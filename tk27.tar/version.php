<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'qtype_turtipskupon';
$plugin->version   = 2015082700;
$plugin->requires  = 2011102700;
$plugin->maturity  = MATURITY_ALPHA;
